"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";

const tabs = [
  { href: "/", label: "Home", icon: HomeIcon },
  { href: "/drives", label: "Drives", icon: DriveIcon },
  { href: "/report", label: "Report", icon: ReportIcon },
  { href: "/reels", label: "Reels", icon: ReelIcon },
];

export default function NavBar() {
  const pathname = usePathname();
  const { data: session } = useSession();

  return (
    <>
      <header className="sticky top-0 z-40 hidden border-b border-canopy-200/60 bg-stone-50/90 backdrop-blur md:block">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-2">
            <Logo />
            <span className="font-display text-xl font-medium tracking-tight text-canopy-900">
              Saafnikk
            </span>
          </Link>

          <nav className="flex items-center gap-1">
            {tabs.map((t) => (
              <Link
                key={t.href}
                href={t.href}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  pathname === t.href
                    ? "bg-canopy-800 text-stone-50"
                    : "text-canopy-800 hover:bg-canopy-100"
                }`}
              >
                {t.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {session?.user ? (
              <>
                <Link href="/notifications" className="rounded-full p-2 text-canopy-800 hover:bg-canopy-100" aria-label="Notifications">
                  <BellIcon />
                </Link>
                <Link href="/wallet" className="rounded-full p-2 text-canopy-800 hover:bg-canopy-100" aria-label="Wallet">
                  <WalletIcon />
                </Link>
                {session.user.role === "ADMIN" && (
                  <Link href="/admin" className="text-sm font-medium text-soil-700 hover:underline">
                    Admin
                  </Link>
                )}
                <Link href={`/profile/${session.user.username}`} className="flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-canopy-700 text-sm font-semibold text-stone-50">
                    {session.user.name?.[0]?.toUpperCase() ?? "U"}
                  </span>
                </Link>
                <button
                  onClick={() => signOut({ callbackUrl: "/" })}
                  className="text-sm font-medium text-canopy-800/70 hover:text-canopy-900"
                >
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="text-sm font-medium text-canopy-800 hover:text-canopy-900">
                  Log in
                </Link>
                <Link
                  href="/register"
                  className="rounded-full bg-canopy-800 px-4 py-2 text-sm font-medium text-stone-50 hover:bg-canopy-700"
                >
                  Join Saafnikk
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-canopy-200/60 bg-stone-50/95 px-4 backdrop-blur md:hidden">
        <Link href="/" className="flex items-center gap-2">
          <Logo small />
          <span className="font-display text-lg font-medium text-canopy-900">Saafnikk</span>
        </Link>
        {session?.user ? (
          <div className="flex items-center gap-3">
            <Link href="/notifications" aria-label="Notifications" className="text-canopy-800">
              <BellIcon />
            </Link>
            <Link href={`/profile/${session.user.username}`}>
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-canopy-700 text-sm font-semibold text-stone-50">
                {session.user.name?.[0]?.toUpperCase() ?? "U"}
              </span>
            </Link>
          </div>
        ) : (
          <Link href="/login" className="text-sm font-medium text-canopy-800">
            Log in
          </Link>
        )}
      </header>

      {/* Mobile bottom tab bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-5 border-t border-canopy-200/60 bg-stone-50/95 backdrop-blur md:hidden">
        {tabs.map((t) => (
          <Link
            key={t.href}
            href={t.href}
            className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${
              pathname === t.href ? "text-canopy-800" : "text-canopy-800/50"
            }`}
          >
            <t.icon active={pathname === t.href} />
            {t.label}
          </Link>
        ))}
        <Link
          href={session?.user ? `/profile/${session.user.username}` : "/login"}
          className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${
            pathname.startsWith("/profile") ? "text-canopy-800" : "text-canopy-800/50"
          }`}
        >
          <ProfileIcon />
          Profile
        </Link>
      </nav>
    </>
  );
}

function Logo({ small }: { small?: boolean }) {
  const s = small ? 26 : 32;
  return (
    <svg width={s} height={s} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="20" cy="20" r="18" stroke="#1b4332" strokeWidth="2.2" />
      <path
        d="M20 8c-4 4-6 8-6 12a6 6 0 0012 0c0-4-2-8-6-12z"
        fill="#40916c"
      />
      <path d="M20 20v10" stroke="#5c3a22" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function HomeIcon({ active }: { active?: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M4 11.5L12 4l8 7.5V20a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1v-8.5z" stroke={active ? "#1b4332" : "#1b433280"} strokeWidth="1.7" strokeLinejoin="round" />
    </svg>
  );
}
function DriveIcon({ active }: { active?: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M12 21s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z" stroke={active ? "#1b4332" : "#1b433280"} strokeWidth="1.7" />
      <circle cx="12" cy="9" r="2.4" stroke={active ? "#1b4332" : "#1b433280"} strokeWidth="1.7" />
    </svg>
  );
}
function ReportIcon({ active }: { active?: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M12 9v4M12 16.5h.01M3 18l9-14 9 14a1 1 0 01-.9 1.5H3.9A1 1 0 013 18z" stroke={active ? "#1b4332" : "#1b433280"} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function ReelIcon({ active }: { active?: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3.5" y="3.5" width="17" height="17" rx="3" stroke={active ? "#1b4332" : "#1b433280"} strokeWidth="1.7" />
      <path d="M10.5 9l4.5 3-4.5 3V9z" fill={active ? "#1b4332" : "#1b433280"} />
    </svg>
  );
}
function ProfileIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="3.5" stroke="#1b433280" strokeWidth="1.7" />
      <path d="M4.5 20c1.4-3.8 4.5-5.5 7.5-5.5s6.1 1.7 7.5 5.5" stroke="#1b433280" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}
function BellIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5H4.5S6 14 6 10z" stroke="#1b4332" strokeWidth="1.7" strokeLinejoin="round" />
      <path d="M9.5 18.5a2.5 2.5 0 005 0" stroke="#1b4332" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}
function WalletIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="6" width="18" height="13" rx="2" stroke="#1b4332" strokeWidth="1.7" />
      <path d="M3 10h18" stroke="#1b4332" strokeWidth="1.7" />
      <circle cx="16.5" cy="14" r="1.2" fill="#1b4332" />
    </svg>
  );
}
