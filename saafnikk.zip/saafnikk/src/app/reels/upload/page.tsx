"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function UploadReelPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!session?.user) {
      router.push("/login");
      return;
    }
    if (!file) {
      setError("Please choose a video or photo.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const uploadForm = new FormData();
      uploadForm.append("file", file);
      const uploadRes = await fetch("/api/upload", { method: "POST", body: uploadForm });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) throw new Error(uploadData.error ?? "Upload failed.");

      const res = await fetch("/api/reels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caption: caption || undefined,
          mediaUrl: uploadData.url,
          mediaType: file.type.startsWith("video") ? "VIDEO" : "IMAGE",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not upload reel.");
      router.push("/reels");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-display text-3xl text-canopy-900">Share a reel</h1>
      <p className="mt-2 text-sm text-canopy-900/60">Show off your clean-up or plantation moment.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <label className="block">
          <span className="mb-1 block text-sm font-medium text-canopy-900">Video or photo</span>
          <input
            type="file"
            accept="video/mp4,video/webm,image/png,image/jpeg,image/webp"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="block w-full text-sm text-canopy-900"
          />
        </label>

        <label className="block">
          <span className="mb-1 block text-sm font-medium text-canopy-900">Caption (optional)</span>
          <textarea
            rows={3}
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
          />
        </label>

        {error && <p className="text-sm text-red-700">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-canopy-800 py-3 text-sm font-medium text-stone-50 hover:bg-canopy-700 disabled:opacity-60"
        >
          {loading ? "Uploading…" : "Post reel"}
        </button>
      </form>
    </div>
  );
}
