"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";

type Reel = {
  id: string;
  caption: string | null;
  mediaUrl: string;
  mediaType: "VIDEO" | "IMAGE";
  author: { name: string; username: string };
  _count: { likes: number; comments: number };
};

export default function ReelsPage() {
  const { data: session } = useSession();
  const [reels, setReels] = useState<Reel[]>([]);
  const [liked, setLiked] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/reels")
      .then((r) => r.json())
      .then((d) => {
        setReels(d.reels ?? []);
        setLoading(false);
      });
  }, []);

  async function toggleLike(id: string) {
    if (!session?.user) return;
    setLiked((l) => ({ ...l, [id]: !l[id] }));
    setReels((rs) =>
      rs.map((r) =>
        r.id === id
          ? { ...r, _count: { ...r._count, likes: r._count.likes + (liked[id] ? -1 : 1) } }
          : r
      )
    );
    await fetch(`/api/reels/${id}/like`, { method: "POST" });
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-canopy-900">Reels</h1>
        <Link href="/reels/upload" className="rounded-full bg-canopy-800 px-4 py-2 text-xs font-medium text-stone-50 hover:bg-canopy-700">
          + Upload
        </Link>
      </div>

      <div className="mt-6 space-y-6">
        {loading && <p className="text-sm text-canopy-900/50">Loading reels…</p>}
        {!loading && reels.length === 0 && (
          <p className="text-sm text-canopy-900/50">No reels yet — be the first to share your clean-up moment.</p>
        )}
        {reels.map((reel) => (
          <div key={reel.id} className="overflow-hidden rounded-xl border border-canopy-200 bg-stone-50">
            <div className="relative aspect-[9/16] w-full bg-canopy-900">
              {reel.mediaType === "VIDEO" ? (
                <video src={reel.mediaUrl} controls playsInline className="h-full w-full object-cover" />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={reel.mediaUrl} alt={reel.caption ?? "Reel"} className="h-full w-full object-cover" />
              )}
            </div>
            <div className="p-4">
              <p className="text-sm font-medium text-canopy-900">@{reel.author.username}</p>
              {reel.caption && <p className="mt-1 text-sm text-canopy-900/70">{reel.caption}</p>}
              <div className="mt-3 flex items-center gap-4 text-xs text-canopy-900/60">
                <button onClick={() => toggleLike(reel.id)} className="flex items-center gap-1 hover:text-canopy-900">
                  {liked[reel.id] ? "💚" : "🤍"} {reel._count.likes}
                </button>
                <span>💬 {reel._count.comments}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
