"use client";

import { useState } from "react";

export default function FollowButton({ userId, initialFollowing }: { userId: string; initialFollowing: boolean }) {
  const [following, setFollowing] = useState(initialFollowing);
  const [loading, setLoading] = useState(false);

  async function toggle() {
    setLoading(true);
    const res = await fetch("/api/follow", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetUserId: userId }),
    });
    if (res.ok) {
      const data = await res.json();
      setFollowing(data.following);
    }
    setLoading(false);
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className={`mt-2 rounded-full px-4 py-1.5 text-xs font-medium ${
        following ? "bg-canopy-100 text-canopy-800" : "bg-canopy-800 text-stone-50"
      }`}
    >
      {following ? "Following" : "Follow"}
    </button>
  );
}
