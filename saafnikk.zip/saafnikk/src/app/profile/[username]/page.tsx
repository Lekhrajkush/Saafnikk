import { notFound } from "next/navigation";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import FollowButton from "./FollowButton";

export const dynamic = "force-dynamic";

export default async function ProfilePage({ params }: { params: { username: string } }) {
  const session = await getServerSession(authOptions);

  const user = await prisma.user.findUnique({
    where: { username: params.username },
    include: {
      reels: { orderBy: { createdAt: "desc" }, take: 12 },
      _count: { select: { followers: true, following: true, drivesCreated: true, driveParticipants: true } },
    },
  });

  if (!user) notFound();

  const isFollowing = session?.user
    ? !!(await prisma.follow.findUnique({
        where: { followerId_followingId: { followerId: session.user.id, followingId: user.id } },
      }))
    : false;

  const isSelf = session?.user?.id === user.id;

  return (
    <div className="mx-auto max-w-2xl">
      <div className="flex items-center gap-5">
        <span className="flex h-20 w-20 items-center justify-center rounded-full bg-canopy-700 font-display text-2xl text-stone-50">
          {user.name[0]?.toUpperCase()}
        </span>
        <div className="flex-1">
          <h1 className="font-display text-2xl text-canopy-900">{user.name}</h1>
          <p className="text-sm text-canopy-900/50">
            @{user.username}
            {user.institution ? ` · ${user.institution}` : ""}
          </p>
          {!isSelf && session?.user && <FollowButton userId={user.id} initialFollowing={isFollowing} />}
        </div>
      </div>

      {user.bio && <p className="mt-4 text-sm text-canopy-900/70">{user.bio}</p>}

      <div className="mt-6 flex gap-8">
        <Stat value={user._count.followers} label="followers" />
        <Stat value={user._count.following} label="following" />
        <Stat value={user._count.drivesCreated} label="drives led" />
        <Stat value={user.points} label="points" />
      </div>

      <div className="mt-10">
        <h2 className="font-display text-lg text-canopy-900">Reels</h2>
        {user.reels.length === 0 ? (
          <p className="mt-3 text-sm text-canopy-900/50">No reels yet.</p>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-2">
            {user.reels.map((r) => (
              <div key={r.id} className="relative aspect-[9/16] overflow-hidden rounded-md bg-canopy-900">
                {r.mediaType === "IMAGE" ? (
                  <Image src={r.mediaUrl} alt="" fill className="object-cover" unoptimized />
                ) : (
                  <video src={r.mediaUrl} className="h-full w-full object-cover" muted />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <p className="font-display text-lg text-canopy-900">{value}</p>
      <p className="text-xs text-canopy-900/50">{label}</p>
    </div>
  );
}
