import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [driveCount, reportCount, userCount, upcomingDrives] = await Promise.all([
    prisma.drive.count(),
    prisma.report.count({ where: { status: "RESOLVED" } }),
    prisma.user.count(),
    prisma.drive.findMany({
      where: { status: "UPCOMING" },
      orderBy: { startTime: "asc" },
      take: 3,
      include: { leader: { select: { name: true, username: true } }, _count: { select: { participants: true } } },
    }),
  ]);

  return (
    <div className="space-y-16">
      {/* Hero */}
      <section className="grid items-center gap-10 md:grid-cols-2 md:gap-16">
        <div>
          <p className="mb-3 font-display text-sm italic text-soil-700">vikas bhi, prakriti bhi</p>
          <h1 className="font-display text-4xl font-medium leading-[1.1] text-canopy-900 md:text-5xl">
            Small circles of people,
            <br /> cleaning up whole neighbourhoods.
          </h1>
          <p className="mt-5 max-w-md text-[15px] leading-relaxed text-canopy-900/70">
            Saafnikk connects volunteers, schools and colleges across India into
            local drives — clean-ups, plantations, and awareness walks — so growth
            and nature can move forward together.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/drives" className="rounded-full bg-canopy-800 px-6 py-3 text-sm font-medium text-stone-50 hover:bg-canopy-700">
              Find a drive near you
            </Link>
            <Link href="/report" className="rounded-full border border-canopy-800 px-6 py-3 text-sm font-medium text-canopy-800 hover:bg-canopy-100">
              Report a dirty spot
            </Link>
          </div>
          <div className="mt-10 flex gap-8">
            <Stat label="drives run" value={driveCount} />
            <Stat label="spots cleaned" value={reportCount} />
            <Stat label="members" value={userCount} />
          </div>
        </div>

        <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xl bg-canopy-800">
          <svg viewBox="0 0 400 500" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice">
            <defs>
              <radialGradient id="glow" cx="50%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#40916c" />
                <stop offset="100%" stopColor="#1b4332" />
              </radialGradient>
            </defs>
            <rect width="400" height="500" fill="url(#glow)" />
            <circle cx="200" cy="230" r="150" fill="none" stroke="#f6e6b4" strokeOpacity="0.35" strokeWidth="1.5" />
            <circle cx="200" cy="230" r="110" fill="none" stroke="#f6e6b4" strokeOpacity="0.25" strokeWidth="1.5" />
            <path d="M200 150c-30 30-45 60-45 90a45 45 0 0090 0c0-30-15-60-45-90z" fill="#f6e6b4" opacity="0.9" />
            <path d="M200 240v130" stroke="#f6e6b4" strokeWidth="3" strokeLinecap="round" opacity="0.7" />
          </svg>
        </div>
      </section>

      {/* Upcoming drives */}
      <section>
        <div className="mb-5 flex items-end justify-between">
          <h2 className="font-display text-2xl text-canopy-900">Upcoming drives</h2>
          <Link href="/drives" className="text-sm font-medium text-canopy-700 hover:underline">
            See all
          </Link>
        </div>
        {upcomingDrives.length === 0 ? (
          <EmptyState
            title="No drives scheduled yet"
            body="Be the first to organise one in your area — it takes five minutes."
            actionHref="/drives/new"
            actionLabel="Start a drive"
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {upcomingDrives.map((d) => (
              <Link
                key={d.id}
                href={`/drives/${d.id}`}
                className="rounded-lg border border-canopy-200 bg-stone-50 p-5 transition-colors hover:border-canopy-400"
              >
                <p className="text-xs font-medium uppercase tracking-wide text-soil-500">{d.category}</p>
                <h3 className="mt-1 font-display text-lg text-canopy-900">{d.title}</h3>
                <p className="mt-1 text-sm text-canopy-900/60">{d.locationName}</p>
                <div className="mt-4 flex items-center justify-between text-xs text-canopy-900/50">
                  <span>{new Date(d.startTime).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</span>
                  <span>{d._count.participants} joined</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* How it works */}
      <section className="rounded-xl bg-canopy-50 p-8 md:p-12">
        <h2 className="font-display text-2xl text-canopy-900">How Saafnikk works</h2>
        <div className="mt-8 grid gap-8 md:grid-cols-4">
          {[
            { t: "Spot it", d: "See litter, a dumping site, or a bare patch of land? Report it with a photo and location." },
            { t: "Rally it", d: "Leaders turn reports into drives. Schools and colleges form their own committees." },
            { t: "Show up", d: "Join a drive, clean or plant together, and share the moment as a reel." },
            { t: "Grow it", d: "Earn recognition, build a following, and sponsors can back drives that matter." },
          ].map((s) => (
            <div key={s.t}>
              <h3 className="font-display text-lg text-canopy-900">{s.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-canopy-900/65">{s.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="font-display text-2xl text-canopy-900">{value.toLocaleString("en-IN")}</p>
      <p className="text-xs text-canopy-900/55">{label}</p>
    </div>
  );
}

export function EmptyState({
  title,
  body,
  actionHref,
  actionLabel,
}: {
  title: string;
  body: string;
  actionHref?: string;
  actionLabel?: string;
}) {
  return (
    <div className="rounded-lg border border-dashed border-canopy-300 bg-canopy-50/50 p-10 text-center">
      <p className="font-display text-lg text-canopy-900">{title}</p>
      <p className="mx-auto mt-2 max-w-sm text-sm text-canopy-900/60">{body}</p>
      {actionHref && actionLabel && (
        <Link
          href={actionHref}
          className="mt-5 inline-block rounded-full bg-canopy-800 px-5 py-2.5 text-sm font-medium text-stone-50 hover:bg-canopy-700"
        >
          {actionLabel}
        </Link>
      )}
    </div>
  );
}
