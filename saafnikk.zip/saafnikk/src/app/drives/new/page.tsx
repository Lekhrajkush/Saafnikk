"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function NewDrivePage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "CLEANUP",
    locationName: "",
    address: "",
    latitude: "",
    longitude: "",
    startTime: "",
    endTime: "",
    capacity: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (status === "unauthenticated") {
    router.push("/login");
  }

  function detectLocation() {
    navigator.geolocation.getCurrentPosition((pos) => {
      setForm((f) => ({
        ...f,
        latitude: String(pos.coords.latitude.toFixed(6)),
        longitude: String(pos.coords.longitude.toFixed(6)),
      }));
    });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/drives", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          latitude: Number(form.latitude),
          longitude: Number(form.longitude),
          capacity: form.capacity ? Number(form.capacity) : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not create drive.");
      router.push(`/drives/${data.drive.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="font-display text-3xl text-canopy-900">Start a drive</h1>
      <p className="mt-2 text-sm text-canopy-900/60">
        Set the details — nearby members will get notified once it's live.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} required />
        <label className="block">
          <span className="mb-1 block text-sm font-medium text-canopy-900">Description</span>
          <textarea
            required
            rows={4}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
          />
        </label>

        <label className="block">
          <span className="mb-1 block text-sm font-medium text-canopy-900">Category</span>
          <select
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value })}
            className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
          >
            <option value="CLEANUP">Clean-up</option>
            <option value="PLANTATION">Plantation</option>
            <option value="AWARENESS">Awareness</option>
            <option value="RECYCLING">Recycling</option>
            <option value="OTHER">Other</option>
          </select>
        </label>

        <Field label="Location name" value={form.locationName} onChange={(v) => setForm({ ...form, locationName: v })} required hint="e.g. Marine Drive, Mumbai" />
        <Field label="Address (optional)" value={form.address} onChange={(v) => setForm({ ...form, address: v })} />

        <div>
          <button type="button" onClick={detectLocation} className="text-sm font-medium text-canopy-700 hover:underline">
            📍 Use my current location
          </button>
          <div className="mt-2 grid grid-cols-2 gap-3">
            <Field label="Latitude" value={form.latitude} onChange={(v) => setForm({ ...form, latitude: v })} required />
            <Field label="Longitude" value={form.longitude} onChange={(v) => setForm({ ...form, longitude: v })} required />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Start" type="datetime-local" value={form.startTime} onChange={(v) => setForm({ ...form, startTime: v })} required />
          <Field label="End" type="datetime-local" value={form.endTime} onChange={(v) => setForm({ ...form, endTime: v })} required />
        </div>

        <Field label="Capacity (optional)" type="number" value={form.capacity} onChange={(v) => setForm({ ...form, capacity: v })} />

        {error && <p className="text-sm text-red-700">{error}</p>}

        <button
          type="submit"
          disabled={loading || !session?.user}
          className="w-full rounded-full bg-canopy-800 py-3 text-sm font-medium text-stone-50 hover:bg-canopy-700 disabled:opacity-60"
        >
          {loading ? "Creating…" : "Create drive"}
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  hint,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-canopy-900">{label}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
      />
      {hint && <span className="mt-1 block text-xs text-canopy-900/45">{hint}</span>}
    </label>
  );
}
