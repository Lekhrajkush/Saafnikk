import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import JoinButton from "./JoinButton";

export const dynamic = "force-dynamic";

export default async function DriveDetailPage({ params }: { params: { id: string } }) {
  const drive = await prisma.drive.findUnique({
    where: { id: params.id },
    include: {
      leader: { select: { id: true, name: true, username: true } },
      participants: { include: { user: { select: { name: true, username: true } } }, take: 20 },
      sponsorship: { include: { sponsor: { select: { name: true } } } },
      _count: { select: { participants: true } },
    },
  });

  if (!drive) notFound();

  return (
    <div className="mx-auto max-w-2xl">
      <p className="text-xs font-medium uppercase tracking-wide text-soil-500">{drive.category}</p>
      <h1 className="mt-1 font-display text-3xl text-canopy-900">{drive.title}</h1>
      <p className="mt-2 text-sm text-canopy-900/60">
        Organised by {drive.leader.name} (@{drive.leader.username})
        {drive.isSponsored && drive.sponsorship ? ` · sponsored by ${drive.sponsorship.sponsor.name}` : ""}
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <InfoCard label="When" value={`${new Date(drive.startTime).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })} – ${new Date(drive.endTime).toLocaleTimeString("en-IN", { timeStyle: "short" })}`} />
        <InfoCard label="Where" value={`${drive.locationName}${drive.address ? `, ${drive.address}` : ""}`} />
        <InfoCard label="Participants" value={`${drive._count.participants}${drive.capacity ? ` / ${drive.capacity}` : ""}`} />
        <InfoCard label="Status" value={drive.status.charAt(0) + drive.status.slice(1).toLowerCase()} />
      </div>

      <div className="mt-8">
        <h2 className="font-display text-lg text-canopy-900">About this drive</h2>
        <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-canopy-900/70">{drive.description}</p>
      </div>

      <div className="mt-8">
        <JoinButton driveId={drive.id} />
      </div>

      {drive.participants.length > 0 && (
        <div className="mt-10">
          <h2 className="font-display text-lg text-canopy-900">Who's coming</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {drive.participants.map((p) => (
              <span key={p.id} className="rounded-full bg-canopy-100 px-3 py-1 text-xs font-medium text-canopy-800">
                {p.user.name}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function InfoCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-canopy-200 bg-stone-50 p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-canopy-900/45">{label}</p>
      <p className="mt-1 text-sm text-canopy-900">{value}</p>
    </div>
  );
}
