"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function JoinButton({ driveId }: { driveId: string }) {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function toggleJoin() {
    if (!session?.user) {
      router.push("/login");
      return;
    }
    setLoading(true);
    setError(null);
    const res = await fetch(`/api/drives/${driveId}/join`, { method: "POST" });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Something went wrong.");
      return;
    }
    router.refresh();
  }

  return (
    <div>
      <button
        onClick={toggleJoin}
        disabled={loading}
        className="rounded-full bg-canopy-800 px-6 py-3 text-sm font-medium text-stone-50 hover:bg-canopy-700 disabled:opacity-60"
      >
        {loading ? "Please wait…" : "Join this drive"}
      </button>
      {error && <p className="mt-2 text-sm text-red-700">{error}</p>}
    </div>
  );
}
