"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { EmptyState } from "@/app/page";

type Drive = {
  id: string;
  title: string;
  category: string;
  locationName: string;
  startTime: string;
  distanceKm: number | null;
  leader: { name: string; username: string };
  _count: { participants: number };
};

const CATEGORIES = ["ALL", "CLEANUP", "PLANTATION", "AWARENESS", "RECYCLING", "OTHER"];

export default function DrivesPage() {
  const [drives, setDrives] = useState<Drive[]>([]);
  const [category, setCategory] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [locating, setLocating] = useState(false);
  const [radius, setRadius] = useState(50);

  async function load(coords?: { lat: number; lng: number }) {
    setLoading(true);
    const params = new URLSearchParams({ status: "UPCOMING" });
    if (category !== "ALL") params.set("category", category);
    if (coords) {
      params.set("lat", String(coords.lat));
      params.set("lng", String(coords.lng));
      params.set("radiusKm", String(radius));
    }
    const res = await fetch(`/api/drives?${params.toString()}`);
    const data = await res.json();
    setDrives(data.drives ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  function useMyLocation() {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        load({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocating(false);
      },
      () => setLocating(false)
    );
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-canopy-900">Drives across India</h1>
          <p className="mt-1 text-sm text-canopy-900/60">Clean-ups and plantations, organised by people near you.</p>
        </div>
        <Link href="/drives/new" className="rounded-full bg-canopy-800 px-5 py-2.5 text-sm font-medium text-stone-50 hover:bg-canopy-700">
          + Start a drive
        </Link>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`rounded-full px-3.5 py-1.5 text-xs font-medium ${
                category === c ? "bg-canopy-800 text-stone-50" : "bg-canopy-100 text-canopy-800 hover:bg-canopy-200"
              }`}
            >
              {c[0] + c.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
        <button
          onClick={useMyLocation}
          disabled={locating}
          className="ml-auto rounded-full border border-canopy-300 px-3.5 py-1.5 text-xs font-medium text-canopy-800 hover:bg-canopy-100"
        >
          {locating ? "Locating…" : "📍 Near me"}
        </button>
      </div>

      {loading ? (
        <p className="mt-10 text-sm text-canopy-900/50">Loading drives…</p>
      ) : drives.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            title="No drives found"
            body="Try a different category, or start the first one in your area."
            actionHref="/drives/new"
            actionLabel="Start a drive"
          />
        </div>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {drives.map((d) => (
            <Link
              key={d.id}
              href={`/drives/${d.id}`}
              className="rounded-lg border border-canopy-200 bg-stone-50 p-5 hover:border-canopy-400"
            >
              <p className="text-xs font-medium uppercase tracking-wide text-soil-500">{d.category}</p>
              <h3 className="mt-1 font-display text-lg text-canopy-900">{d.title}</h3>
              <p className="mt-1 text-sm text-canopy-900/60">{d.locationName}</p>
              <p className="mt-1 text-xs text-canopy-900/45">by {d.leader.name}</p>
              <div className="mt-4 flex items-center justify-between text-xs text-canopy-900/50">
                <span>{new Date(d.startTime).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</span>
                <span>{d._count.participants} joined{d.distanceKm !== null ? ` · ${d.distanceKm.toFixed(1)} km away` : ""}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
