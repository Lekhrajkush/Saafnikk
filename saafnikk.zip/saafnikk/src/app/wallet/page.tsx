"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

type Transaction = {
  id: string;
  amount: number;
  type: string;
  status: string;
  note: string | null;
  createdAt: string;
};

export default function WalletPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
      return;
    }
    if (status === "authenticated") {
      fetch("/api/wallet")
        .then((r) => r.json())
        .then((d) => {
          setBalance(d.wallet.balance);
          setTransactions(d.wallet.transactions);
          setLoading(false);
        });
    }
  }, [status, router]);

  async function requestWithdrawal(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const amt = Number(amount);
    if (!amt || amt <= 0) {
      setError("Enter a valid amount.");
      return;
    }
    const res = await fetch("/api/wallet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: amt }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Could not submit withdrawal.");
      return;
    }
    setBalance((b) => b - amt);
    setTransactions((t) => [data.transaction, ...t]);
    setAmount("");
  }

  if (loading) return <p className="text-sm text-canopy-900/50">Loading wallet…</p>;

  return (
    <div className="mx-auto max-w-md">
      <h1 className="font-display text-3xl text-canopy-900">Your wallet</h1>
      <p className="mt-2 text-sm text-canopy-900/60">
        Earnings from sponsored drives and engagement rewards land here.
      </p>

      <div className="mt-6 rounded-xl bg-canopy-800 p-6 text-stone-50">
        <p className="text-xs uppercase tracking-wide text-stone-50/60">Available balance</p>
        <p className="mt-1 font-display text-3xl">₹{balance.toFixed(2)}</p>
      </div>

      <form onSubmit={requestWithdrawal} className="mt-6 flex gap-2">
        <input
          type="number"
          min="1"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount to withdraw"
          className="flex-1 rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
        />
        <button className="rounded-lg bg-canopy-800 px-4 py-2.5 text-sm font-medium text-stone-50 hover:bg-canopy-700">
          Withdraw
        </button>
      </form>
      {error && <p className="mt-2 text-sm text-red-700">{error}</p>}
      <p className="mt-2 text-xs text-canopy-900/45">
        Withdrawals are queued for payout processing once a payment gateway is connected.
      </p>

      <div className="mt-10">
        <h2 className="font-display text-lg text-canopy-900">Transaction history</h2>
        {transactions.length === 0 ? (
          <p className="mt-3 text-sm text-canopy-900/50">No transactions yet.</p>
        ) : (
          <div className="mt-3 divide-y divide-canopy-200 rounded-lg border border-canopy-200 bg-stone-50">
            {transactions.map((t) => (
              <div key={t.id} className="flex items-center justify-between p-3.5">
                <div>
                  <p className="text-sm font-medium text-canopy-900">
                    {t.type.replace("_", " ").toLowerCase()}
                  </p>
                  <p className="text-xs text-canopy-900/45">{new Date(t.createdAt).toLocaleDateString("en-IN")}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-medium ${t.type === "WITHDRAWAL" ? "text-red-700" : "text-canopy-800"}`}>
                    {t.type === "WITHDRAWAL" ? "−" : "+"}₹{t.amount.toFixed(2)}
                  </p>
                  <p className="text-xs text-canopy-900/45">{t.status.toLowerCase()}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
