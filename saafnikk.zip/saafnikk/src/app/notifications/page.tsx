"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

type Notification = {
  id: string;
  type: string;
  message: string;
  read: boolean;
  createdAt: string;
  linkUrl: string | null;
};

export default function NotificationsPage() {
  const { status } = useSession();
  const router = useRouter();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
      return;
    }
    if (status === "authenticated") {
      fetch("/api/notifications")
        .then((r) => r.json())
        .then((d) => {
          setNotifications(d.notifications ?? []);
          setLoading(false);
        });
      fetch("/api/notifications", { method: "PATCH" });
    }
  }, [status, router]);

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="font-display text-3xl text-canopy-900">Notifications</h1>

      {loading ? (
        <p className="mt-6 text-sm text-canopy-900/50">Loading…</p>
      ) : notifications.length === 0 ? (
        <p className="mt-6 text-sm text-canopy-900/50">You're all caught up.</p>
      ) : (
        <div className="mt-6 divide-y divide-canopy-200 rounded-lg border border-canopy-200 bg-stone-50">
          {notifications.map((n) => (
            <Link
              key={n.id}
              href={n.linkUrl ?? "#"}
              className={`block p-4 hover:bg-canopy-50 ${!n.read ? "bg-canopy-50/60" : ""}`}
            >
              <p className="text-sm text-canopy-900">{n.message}</p>
              <p className="mt-1 text-xs text-canopy-900/40">
                {new Date(n.createdAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
