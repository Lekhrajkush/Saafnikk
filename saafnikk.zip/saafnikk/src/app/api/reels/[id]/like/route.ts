import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const reel = await prisma.reel.findUnique({ where: { id: params.id } });
  if (!reel) return NextResponse.json({ error: "Reel not found." }, { status: 404 });

  const existing = await prisma.reelLike.findUnique({
    where: { reelId_userId: { reelId: params.id, userId: session.user.id } },
  });

  if (existing) {
    await prisma.reelLike.delete({ where: { id: existing.id } });
    return NextResponse.json({ liked: false });
  }

  await prisma.reelLike.create({ data: { reelId: params.id, userId: session.user.id } });

  if (reel.authorId !== session.user.id) {
    await prisma.notification.create({
      data: {
        recipientId: reel.authorId,
        actorId: session.user.id,
        type: "REEL_LIKE",
        message: `${session.user.name} liked your reel.`,
        linkUrl: `/reels?id=${reel.id}`,
      },
    });
  }

  return NextResponse.json({ liked: true });
}
