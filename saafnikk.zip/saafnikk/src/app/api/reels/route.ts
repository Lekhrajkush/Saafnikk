import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const createSchema = z.object({
  caption: z.string().max(500).optional(),
  mediaUrl: z.string().min(1),
  mediaType: z.enum(["VIDEO", "IMAGE"]).default("VIDEO"),
  thumbnailUrl: z.string().optional(),
});

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const cursor = searchParams.get("cursor") ?? undefined;
  const authorUsername = searchParams.get("author") ?? undefined;

  const reels = await prisma.reel.findMany({
    where: authorUsername ? { author: { username: authorUsername } } : undefined,
    include: {
      author: { select: { id: true, name: true, username: true, avatarUrl: true } },
      _count: { select: { likes: true, comments: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 10,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
  });

  const nextCursor = reels.length === 10 ? reels[reels.length - 1].id : null;
  return NextResponse.json({ reels, nextCursor });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    const reel = await prisma.reel.create({
      data: { ...data, authorId: session.user.id },
    });

    return NextResponse.json({ reel }, { status: 201 });
  } catch (err: any) {
    if (err?.issues) {
      return NextResponse.json({ error: err.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Could not upload reel." }, { status: 500 });
  }
}
