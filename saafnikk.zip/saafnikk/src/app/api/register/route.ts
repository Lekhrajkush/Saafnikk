import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  name: z.string().min(2).max(80),
  username: z
    .string()
    .min(3)
    .max(24)
    .regex(/^[a-z0-9_.]+$/, "Username can only contain lowercase letters, numbers, . and _"),
  email: z.string().email(),
  password: z.string().min(8),
  city: z.string().optional(),
  state: z.string().optional(),
  institution: z.string().optional(),
  institutionType: z.enum(["SCHOOL", "COLLEGE", "NGO", "COMPANY", "OTHER"]).optional(),
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    const existing = await prisma.user.findFirst({
      where: { OR: [{ email: data.email.toLowerCase() }, { username: data.username.toLowerCase() }] },
    });
    if (existing) {
      return NextResponse.json(
        { error: "An account with that email or username already exists." },
        { status: 409 }
      );
    }

    const passwordHash = await bcrypt.hash(data.password, 10);

    const user = await prisma.user.create({
      data: {
        name: data.name,
        username: data.username.toLowerCase(),
        email: data.email.toLowerCase(),
        passwordHash,
        city: data.city,
        state: data.state,
        institution: data.institution,
        institutionType: data.institutionType,
        wallet: { create: { balance: 0 } },
      },
      select: { id: true, name: true, username: true, email: true },
    });

    return NextResponse.json({ user }, { status: 201 });
  } catch (err: any) {
    if (err?.issues) {
      return NextResponse.json({ error: err.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
