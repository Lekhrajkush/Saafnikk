import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const createSchema = z.object({
  title: z.string().min(3).max(120),
  description: z.string().max(2000).optional(),
  imageUrl: z.string().min(1),
  latitude: z.number(),
  longitude: z.number(),
  locationName: z.string().optional(),
});

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const reports = await prisma.report.findMany({
    where: status ? { status: status as any } : undefined,
    include: { reporter: { select: { name: true, username: true, avatarUrl: true } } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return NextResponse.json({ reports });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    const report = await prisma.report.create({
      data: { ...data, reporterId: session.user.id },
    });

    return NextResponse.json({ report }, { status: 201 });
  } catch (err: any) {
    if (err?.issues) {
      return NextResponse.json({ error: err.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Could not submit report." }, { status: 500 });
  }
}
