import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const schema = z.object({ targetUserId: z.string() });

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const { targetUserId } = schema.parse(await req.json());
  if (targetUserId === session.user.id) {
    return NextResponse.json({ error: "You can't follow yourself." }, { status: 400 });
  }

  const existing = await prisma.follow.findUnique({
    where: { followerId_followingId: { followerId: session.user.id, followingId: targetUserId } },
  });

  if (existing) {
    await prisma.follow.delete({ where: { id: existing.id } });
    return NextResponse.json({ following: false });
  }

  await prisma.follow.create({
    data: { followerId: session.user.id, followingId: targetUserId },
  });

  await prisma.notification.create({
    data: {
      recipientId: targetUserId,
      actorId: session.user.id,
      type: "NEW_FOLLOWER",
      message: `${session.user.name} started following you.`,
      linkUrl: `/profile/${session.user.username}`,
    },
  });

  return NextResponse.json({ following: true });
}
