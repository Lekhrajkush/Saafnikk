import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const wallet = await prisma.wallet.upsert({
    where: { userId: session.user.id },
    update: {},
    create: { userId: session.user.id, balance: 0 },
    include: { transactions: { orderBy: { createdAt: "desc" }, take: 50 } },
  });

  return NextResponse.json({ wallet });
}

const withdrawSchema = z.object({ amount: z.number().positive() });

// Creates a PENDING withdrawal request. Actually paying out requires wiring a
// payment gateway (Razorpay/Stripe payouts) with your own API keys — see README.
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const { amount } = withdrawSchema.parse(await req.json());

  const wallet = await prisma.wallet.findUnique({ where: { userId: session.user.id } });
  if (!wallet || wallet.balance < amount) {
    return NextResponse.json({ error: "Insufficient balance." }, { status: 400 });
  }

  const [, tx] = await prisma.$transaction([
    prisma.wallet.update({
      where: { id: wallet.id },
      data: { balance: { decrement: amount } },
    }),
    prisma.transaction.create({
      data: {
        walletId: wallet.id,
        amount,
        type: "WITHDRAWAL",
        status: "PENDING",
        note: "Withdrawal requested — pending payout gateway processing.",
      },
    }),
  ]);

  return NextResponse.json({ transaction: tx }, { status: 201 });
}
