import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const drive = await prisma.drive.findUnique({ where: { id: params.id } });
  if (!drive) return NextResponse.json({ error: "Drive not found." }, { status: 404 });

  const existing = await prisma.driveParticipant.findUnique({
    where: { driveId_userId: { driveId: params.id, userId: session.user.id } },
  });

  if (existing) {
    await prisma.driveParticipant.delete({ where: { id: existing.id } });
    return NextResponse.json({ joined: false });
  }

  if (drive.capacity) {
    const count = await prisma.driveParticipant.count({ where: { driveId: params.id } });
    if (count >= drive.capacity) {
      return NextResponse.json({ error: "This drive is full." }, { status: 400 });
    }
  }

  await prisma.driveParticipant.create({
    data: { driveId: params.id, userId: session.user.id },
  });

  if (drive.leaderId !== session.user.id) {
    await prisma.notification.create({
      data: {
        recipientId: drive.leaderId,
        actorId: session.user.id,
        type: "DRIVE_UPDATE",
        message: `${session.user.name} joined your drive "${drive.title}".`,
        linkUrl: `/drives/${drive.id}`,
      },
    });
  }

  return NextResponse.json({ joined: true });
}
