import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { distanceKm } from "@/lib/geo";

const createSchema = z.object({
  title: z.string().min(4).max(120),
  description: z.string().min(10).max(2000),
  category: z.enum(["CLEANUP", "PLANTATION", "AWARENESS", "RECYCLING", "OTHER"]).default("CLEANUP"),
  locationName: z.string().min(2),
  address: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  startTime: z.string(),
  endTime: z.string(),
  capacity: z.number().int().positive().optional(),
  coverImage: z.string().optional(),
});

// GET /api/drives?lat=..&lng=..&radiusKm=50&category=CLEANUP&status=UPCOMING
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const lat = searchParams.get("lat");
  const lng = searchParams.get("lng");
  const radiusKm = Number(searchParams.get("radiusKm") ?? 50);
  const category = searchParams.get("category");
  const status = searchParams.get("status");

  const drives = await prisma.drive.findMany({
    where: {
      ...(category ? { category: category as any } : {}),
      ...(status ? { status: status as any } : {}),
    },
    include: {
      leader: { select: { id: true, name: true, username: true, avatarUrl: true } },
      _count: { select: { participants: true } },
    },
    orderBy: { startTime: "asc" },
    take: 100,
  });

  let result = drives.map((d) => ({ ...d, distanceKm: null as number | null }));

  if (lat && lng) {
    const latN = Number(lat);
    const lngN = Number(lng);
    result = drives
      .map((d) => ({ ...d, distanceKm: distanceKm(latN, lngN, d.latitude, d.longitude) }))
      .filter((d) => d.distanceKm <= radiusKm)
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }

  return NextResponse.json({ drives: result });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    const drive = await prisma.drive.create({
      data: {
        ...data,
        startTime: new Date(data.startTime),
        endTime: new Date(data.endTime),
        leaderId: session.user.id,
        participants: { create: { userId: session.user.id, attended: false } },
      },
    });

    return NextResponse.json({ drive }, { status: 201 });
  } catch (err: any) {
    if (err?.issues) {
      return NextResponse.json({ error: err.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Could not create drive." }, { status: 500 });
  }
}
