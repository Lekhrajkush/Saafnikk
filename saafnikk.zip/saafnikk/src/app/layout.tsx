import type { Metadata } from "next";
import { Fraunces, Work_Sans } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";
import NavBar from "@/components/NavBar";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
});

const workSans = Work_Sans({
  subsets: ["latin"],
  variable: "--font-work-sans",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Saafnikk — vikas bhi, prakriti bhi",
  description:
    "A community-driven platform for a cleaner, greener, more sustainable tomorrow. Join clean-up and plantation drives across India, report dirty spots, and share your impact.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${workSans.variable}`}>
      <body className="font-body antialiased">
        <Providers>
          <NavBar />
          <main className="mx-auto min-h-[calc(100vh-56px)] max-w-6xl px-4 pb-20 pt-6 md:pb-10 md:pt-8">
            {children}
          </main>
        </Providers>
      </body>
    </html>
  );
}
