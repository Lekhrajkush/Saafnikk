"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import Image from "next/image";

type Report = {
  id: string;
  title: string;
  imageUrl: string;
  locationName: string | null;
  status: string;
  createdAt: string;
  reporter: { name: string; username: string };
};

export default function ReportPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [locationName, setLocationName] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [reports, setReports] = useState<Report[]>([]);

  useEffect(() => {
    fetch("/api/reports")
      .then((r) => r.json())
      .then((d) => setReports(d.reports ?? []));
  }, [success]);

  function detectLocation() {
    navigator.geolocation.getCurrentPosition((pos) => {
      setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    });
  }

  function onFileChange(f: File | null) {
    setFile(f);
    setPreview(f ? URL.createObjectURL(f) : null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!session?.user) {
      router.push("/login");
      return;
    }
    if (!coords) {
      setError("Please add the location of the spot.");
      return;
    }
    if (!file) {
      setError("Please attach a photo.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const uploadForm = new FormData();
      uploadForm.append("file", file);
      const uploadRes = await fetch("/api/upload", { method: "POST", body: uploadForm });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) throw new Error(uploadData.error ?? "Upload failed.");

      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description: description || undefined,
          imageUrl: uploadData.url,
          latitude: coords.lat,
          longitude: coords.lng,
          locationName: locationName || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not submit report.");

      setTitle("");
      setDescription("");
      setLocationName("");
      setCoords(null);
      onFileChange(null);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2">
      <div>
        <h1 className="font-display text-3xl text-canopy-900">Report a dirty spot</h1>
        <p className="mt-2 text-sm text-canopy-900/60">
          Flag litter, illegal dumping, or a spot that needs a clean-up drive.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <label className="block">
            <span className="mb-1 block text-sm font-medium text-canopy-900">Photo</span>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => onFileChange(e.target.files?.[0] ?? null)}
              className="block w-full text-sm text-canopy-900"
            />
            {preview && (
              <div className="relative mt-3 h-48 w-full overflow-hidden rounded-lg">
                <Image src={preview} alt="Preview" fill className="object-cover" unoptimized />
              </div>
            )}
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-canopy-900">Title</span>
            <input
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Garbage pile near bus stand"
              className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-canopy-900">Details (optional)</span>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-canopy-900">Area / landmark (optional)</span>
            <input
              value={locationName}
              onChange={(e) => setLocationName(e.target.value)}
              className="w-full rounded-lg border border-canopy-200 bg-stone-50 px-3.5 py-2.5 text-sm text-canopy-900 outline-none focus:border-canopy-500"
            />
          </label>

          <div>
            <button type="button" onClick={detectLocation} className="text-sm font-medium text-canopy-700 hover:underline">
              📍 {coords ? "Location captured" : "Add current location"}
            </button>
          </div>

          {error && <p className="text-sm text-red-700">{error}</p>}
          {success && <p className="text-sm text-canopy-700">Thanks — your report is in.</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-canopy-800 py-3 text-sm font-medium text-stone-50 hover:bg-canopy-700 disabled:opacity-60"
          >
            {loading ? "Submitting…" : "Submit report"}
          </button>
        </form>
      </div>

      <div>
        <h2 className="font-display text-xl text-canopy-900">Recent reports</h2>
        <div className="mt-4 space-y-3">
          {reports.length === 0 && <p className="text-sm text-canopy-900/50">No reports yet.</p>}
          {reports.map((r) => (
            <div key={r.id} className="flex gap-3 rounded-lg border border-canopy-200 bg-stone-50 p-3">
              <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
                <Image src={r.imageUrl} alt={r.title} fill className="object-cover" unoptimized />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-canopy-900">{r.title}</p>
                <p className="truncate text-xs text-canopy-900/50">{r.locationName ?? "Location on file"}</p>
                <span
                  className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-medium ${
                    r.status === "RESOLVED"
                      ? "bg-canopy-100 text-canopy-800"
                      : r.status === "DRIVE_SCHEDULED"
                      ? "bg-sun-200 text-soil-700"
                      : "bg-stone-200 text-canopy-900/60"
                  }`}
                >
                  {r.status.replace("_", " ").toLowerCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
